HI! THANKS FOR DOWNLOADING FULLBY - Free Responsive Grid Wordpress Theme 
by MarchettiDesign.net

THEME INSTALLATION

1) Upload and activate the theme, in Wordpress theme folder.

2) Go to Appearance -> Menu, create new menu, call it "Main" and select primary navigation (next add page to the menu).

3) Repeat step 2, call the second menu "Sub" and select secondary navigation. 

4) To manage sidebars go to Appearance -> Widgets, drag and drop widgets to the sidebar. Primary sidebar on the left. Secondary sidebar on the right.

5) To manage the social icon open open sidebar-primary.php and paste the social links in the social div.

6) To add "Featured" content in the home add the tag "Featured" to the article (you must set the post thumnbnail).

7) The theme put automatically the popular and latest posts in the Primary Sidebar.

8) When you add a new post, to add video paste ID of Youtube video in the Video Box.

9) To insert Gallery use the standard system of Wordpress.

10) For SEO optimization go to  --> Apparence --> Theme options and insert description and google analytics code	


CHANGELOG:

Improvements of version 1.4.2

- update features section


Improvements of version 1.4.1

- fix bug function.php

Improvements of version 1.4

- add page with premium version link 

Improvements of version 1.3

- favicon

- fix menu bug on ipad mini
- featured images full visible on mobile devices

Improvements of version 1.2

- image optimization
- seo optimization
- theme check with wp theme checker